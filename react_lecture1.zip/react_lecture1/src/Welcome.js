import './Welcome.css'

// Default Export : When we make any function default export we can 
// export only one function from the file
function Welcome(props){
    console.log(props);
    return(
        <div className='box'>
            <h1>Welcome {props.name} {props.age}</h1>
        </div>
    );
}


export default Welcome;



// ------------------------ Named Export : we can export multiple function from file -------------------------------------

/*export function Welcome(props){
    console.log(props);
    return(
        <div className='box'>
            <h1>Welcome {props.name} {props.age}</h1>
        </div>
    );
}

export function Greet(props){
    console.log(props);
    return(
        <div className='box'>
            <h1>Welcome {props.name} {props.age}</h1>
        </div>
    );
}*/








