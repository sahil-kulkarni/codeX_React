// this is functional component
import Welcome from "./Welcome"; //we can import default export like this
//import {Welcome,Greet} from './Welcome'; //we can import named export like this
import './Welcome.css'

function App(){
  return (
    <div >
       <Welcome name="Shubham"/>
       <Welcome name="parth"/>
    </div> 
  );
}

export default App;

